<div class="help-ts">
    @if(! $icon)
        <i class="fa fa-info-circle me-1"></i>
    @else
        {!! $icon !!}
    @endif
    <span>{!! $content !!}</span>
</div>
