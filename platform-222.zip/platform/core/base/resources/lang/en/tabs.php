<?php

return [
    'detail' => 'Detail',
    'file' => 'Files',
    'record_note' => 'Record Note',
    'revision' => 'Revision History',
];
