<?php

require_once __DIR__ . '/categories.php';

register_widget(CategoriesWidget::class);
