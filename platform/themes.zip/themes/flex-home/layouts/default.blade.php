{!! Theme::partial('header') !!}

<div id="app">
    {!! Theme::content() !!}
</div>

{!! Theme::partial('footer') !!}
