@include(Theme::getThemeNamespace() . '::views.loop', compact('posts'))
