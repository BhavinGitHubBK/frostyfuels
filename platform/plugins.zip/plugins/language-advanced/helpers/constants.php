<?php

if (! defined('LANGUAGE_ADVANCED_ACTION_SAVED')) {
    define('LANGUAGE_ADVANCED_ACTION_SAVED', 'language-advanced-saved');
}

if (! defined('LANGUAGE_ADVANCED_MODULE_SCREEN_NAME')) {
    define('LANGUAGE_ADVANCED_MODULE_SCREEN_NAME', 'language-advanced');
}
