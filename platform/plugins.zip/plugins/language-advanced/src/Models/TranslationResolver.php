<?php

namespace Botble\LanguageAdvanced\Models;

use Botble\Base\Models\BaseModel;

class TranslationResolver extends BaseModel
{
    public $timestamps = false;
}
