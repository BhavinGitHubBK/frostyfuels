<?php

namespace Botble\Blog\Repositories\Caches;

use Botble\Blog\Repositories\Eloquent\TagRepository;

/**
 * @deprecated
 */
class TagCacheDecorator extends TagRepository
{
}
