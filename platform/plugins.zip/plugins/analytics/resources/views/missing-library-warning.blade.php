<div class="note note-warning">
    <p>{!! BaseHelper::clean(trans('plugins/analytics::analytics.missing_library_warning')) !!}</p>
</div>
