<div class="note note-success">
    <p>{!! BaseHelper::clean(trans('plugins/backup::backup.demo_alert', ['link' => route('backups.index')])) !!}</p>
</div>
