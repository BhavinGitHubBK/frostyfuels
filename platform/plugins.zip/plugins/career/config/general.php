<?php

return [
    'use_language_v2' => env('CAREER_USE_LANGUAGE_VERSION_2', false),
];
