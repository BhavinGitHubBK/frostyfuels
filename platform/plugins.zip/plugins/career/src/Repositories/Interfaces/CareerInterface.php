<?php

namespace Botble\Career\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CareerInterface extends RepositoryInterface
{
}
