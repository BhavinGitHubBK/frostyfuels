<?php

namespace Botble\Career\Repositories\Eloquent;

use Botble\Career\Repositories\Interfaces\CareerInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class CareerRepository extends RepositoriesAbstract implements CareerInterface
{
}
