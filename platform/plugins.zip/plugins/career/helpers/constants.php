<?php

if (! defined('CAREER_MODULE_SCREEN_NAME')) {
    define('CAREER_MODULE_SCREEN_NAME', 'career');
}
