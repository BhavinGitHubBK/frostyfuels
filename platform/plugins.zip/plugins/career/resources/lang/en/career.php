<?php

return [
    'name' => 'Careers',
    'create' => 'New career',
    'location' => 'Location',
    'salary' => 'Salary',
];
