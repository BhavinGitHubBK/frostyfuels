<?php

namespace Botble\AuditLog\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface AuditLogInterface extends RepositoryInterface
{
}
