<?php

namespace Botble\Location\Repositories\Caches;

use Botble\Location\Repositories\Eloquent\CityRepository;

/**
 * @deprecated
 */
class CityCacheDecorator extends CityRepository
{
}
