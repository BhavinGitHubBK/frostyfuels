<?php

namespace Botble\Location\Repositories\Caches;

use Botble\Location\Repositories\Eloquent\CountryRepository;

/**
 * @deprecated
 */
class CountryCacheDecorator extends CountryRepository
{
}
