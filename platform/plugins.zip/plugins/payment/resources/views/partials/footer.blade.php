{!! apply_filters(PAYMENT_FILTER_FOOTER_ASSETS, null) !!}
