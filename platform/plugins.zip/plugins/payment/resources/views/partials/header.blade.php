<link rel="stylesheet" href="{{ asset('vendor/core/plugins/payment/css/payment.css') }}?v=1.1.0">
<script src="{{ asset('vendor/core/plugins/payment/js/payment.js') }}?v=1.1.0"></script>

{!! apply_filters(PAYMENT_FILTER_HEADER_ASSETS, null) !!}
