<?php

return [
    'currency' => env('PAYMENT_DEFAULT_CURRENCY', 'USD'),
];
