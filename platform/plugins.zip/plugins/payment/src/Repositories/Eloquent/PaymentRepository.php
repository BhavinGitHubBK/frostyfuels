<?php

namespace Botble\Payment\Repositories\Eloquent;

use Botble\Payment\Repositories\Interfaces\PaymentInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class PaymentRepository extends RepositoriesAbstract implements PaymentInterface
{
}
