<?php

namespace Botble\Payment\Repositories\Caches;

use Botble\Payment\Repositories\Eloquent\PaymentRepository;

/**
 * @deprecated
 */
class PaymentCacheDecorator extends PaymentRepository
{
}
