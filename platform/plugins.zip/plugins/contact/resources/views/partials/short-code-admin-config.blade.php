<div class="form-group mb-3">
    <p>{{ trans('plugins/contact::contact.shortcode_content_description') }}</p>
</div>
