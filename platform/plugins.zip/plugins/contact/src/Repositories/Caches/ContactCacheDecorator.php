<?php

namespace Botble\Contact\Repositories\Caches;

use Botble\Contact\Repositories\Eloquent\ContactRepository;

/**
 * @deprecated
 */
class ContactCacheDecorator extends ContactRepository
{
}
