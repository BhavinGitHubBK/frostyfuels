<?php

namespace Botble\Contact\Repositories\Eloquent;

use Botble\Contact\Repositories\Interfaces\ContactReplyInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class ContactReplyRepository extends RepositoriesAbstract implements ContactReplyInterface
{
}
