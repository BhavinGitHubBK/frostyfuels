<?php

namespace Botble\Language\Repositories\Eloquent;

use Botble\Language\Repositories\Interfaces\LanguageMetaInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class LanguageMetaRepository extends RepositoriesAbstract implements LanguageMetaInterface
{
}
