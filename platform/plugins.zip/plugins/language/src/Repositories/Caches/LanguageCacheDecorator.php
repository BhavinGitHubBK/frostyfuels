<?php

namespace Botble\Language\Repositories\Caches;

use Botble\Language\Repositories\Eloquent\LanguageRepository;

/**
 * @deprecated
 */
class LanguageCacheDecorator extends LanguageRepository
{
}
