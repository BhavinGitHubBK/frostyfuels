<div class="note note-success">
    <p>{!! BaseHelper::clean(trans('plugins/language::language.current_language_edit_notification', ['language' => $language])) !!}</p>
</div>
