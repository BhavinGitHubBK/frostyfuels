<?php

return [
    'supported' => [],
];
