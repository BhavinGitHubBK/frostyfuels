<?php

return [
    [
        'name' => 'Social Login',
        'flag' => 'social-login.settings',
    ],
];
