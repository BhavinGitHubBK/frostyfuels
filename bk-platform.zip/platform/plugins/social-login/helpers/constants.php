<?php

if (! defined('SOCIAL_LOGIN_MODULE_SCREEN_NAME')) {
    define('SOCIAL_LOGIN_MODULE_SCREEN_NAME', 'social-login');
}
