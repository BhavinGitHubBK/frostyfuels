<?php

if (! defined('PAYSTACK_PAYMENT_METHOD_NAME')) {
    define('PAYSTACK_PAYMENT_METHOD_NAME', 'paystack');
}
