<?php

namespace Botble\Translation\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface TranslationInterface extends RepositoryInterface
{
}
