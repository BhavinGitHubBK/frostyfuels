<?php

namespace Botble\Translation\Repositories\Caches;

use Botble\Translation\Repositories\Eloquent\TranslationRepository;

/**
 * @deprecated
 */
class TranslationCacheDecorator extends TranslationRepository
{
}
