<?php

namespace Botble\Translation\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Translation\Repositories\Interfaces\TranslationInterface;

class TranslationRepository extends RepositoriesAbstract implements TranslationInterface
{
}
