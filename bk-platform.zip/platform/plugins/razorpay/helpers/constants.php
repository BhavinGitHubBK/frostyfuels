<?php

if (! defined('RAZORPAY_PAYMENT_METHOD_NAME')) {
    define('RAZORPAY_PAYMENT_METHOD_NAME', 'razorpay');
}
