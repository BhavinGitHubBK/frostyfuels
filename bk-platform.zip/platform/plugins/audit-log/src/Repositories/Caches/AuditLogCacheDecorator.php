<?php

namespace Botble\AuditLog\Repositories\Caches;

use Botble\AuditLog\Repositories\Eloquent\AuditLogRepository;

/**
 * @deprecated
 */
class AuditLogCacheDecorator extends AuditLogRepository
{
}
