<?php

namespace Botble\Blog\Repositories\Caches;

use Botble\Blog\Repositories\Eloquent\PostRepository;

/**
 * @deprecated
 */
class PostCacheDecorator extends PostRepository
{
}
