<div class="rating_wrap d-inline-block">
    <div class="rating">
        <div class="review_rate" style="width: {{ $star * 20 }}%"></div>
    </div>
</div>
