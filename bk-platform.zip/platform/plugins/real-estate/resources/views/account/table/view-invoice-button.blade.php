<a class="btn btn-icon btn-sm btn-info" href="{{ route('public.account.invoices.show', $item->id) }}" data-original-title="{{ __('View') }}" >
    <i class="fas fa-eye"></i>
</a>
