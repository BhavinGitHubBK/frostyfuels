<a href="#" class="btn btn-icon btn-sm btn-info button-renew" data-section="{{ route('public.account.properties.renew', $item->id) }}" role="button" data-original-title="{{ __('Renew') }}" >
    <i class="fas fa-sync-alt"></i>
</a>
