<?php

return [
    'types' => [
        'add' => 'Add',
        'remove' => 'Remove',
    ],
];
