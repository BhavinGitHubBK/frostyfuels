<?php

return [
    'name' => 'Categories',
    'create' => 'New category',
    'edit' => 'Edit category',
    'menu' => 'Property categories',
    'none' => 'None',
    'total_properties' => 'Total properties',
    'total_projects' => 'Total projects',
    'is_default' => 'Is default',
];
