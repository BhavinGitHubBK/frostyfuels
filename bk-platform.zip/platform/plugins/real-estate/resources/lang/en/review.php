<?php

return [
    'name' => 'Reviews',
    'author' => 'Author',
    'star' => 'Star',
    'content' => 'Content',
    'reviewable' => 'Reviewable',
    'moderation-statuses' => [
        'pending' => 'Pending',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
    ],
];
