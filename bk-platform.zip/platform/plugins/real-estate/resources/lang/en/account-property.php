<?php

return [
    'draft_properties' => 'Draft Properties',
    'pending_properties' => 'Pending Properties',
    'published_properties' => 'Published Properties',
    'properties' => 'Properties',
    'write_property' => 'Write a property',
    'images' => 'Images (maximum :max images)',
];
