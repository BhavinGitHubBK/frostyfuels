<?php

return [
    'name' => 'Real Estate',
    'settings' => 'Settings',
];
