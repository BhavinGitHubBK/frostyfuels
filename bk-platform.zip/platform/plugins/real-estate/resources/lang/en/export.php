<?php

return [
    'properties' => [
        'name' => 'Export Properties',
        'total_properties' => 'Total Properties',
    ],
    'projects' => [
        'name' => 'Export Projects',
        'total_projects' => 'Total Projects',
    ],
    'start_export' => 'Start Export',
    'exporting' => 'Exporting...',
];
