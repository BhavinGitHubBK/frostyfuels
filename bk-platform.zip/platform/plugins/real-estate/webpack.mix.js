let mix = require('laravel-mix');

const path = require('path');
let directory = path.basename(path.resolve(__dirname));

const source = 'platform/plugins/' + directory;
const dist = 'public/vendor/core/plugins/' + directory;

mix.js(source + '/resources/assets/js/components.js', dist + '/js')

mix
    .js(source + '/resources/assets/js/real-estate.js', dist + '/js')
    .js(source + '/resources/assets/js/currencies.js', dist + '/js')
    .js(source + '/resources/assets/js/global-custom-fields.js', dist + '/js')
    .js(source + '/resources/assets/js/custom-fields.js', dist + '/js')
    .sass(source + '/resources/assets/sass/real-estate.scss', dist + '/css')
    .sass(source + '/resources/assets/sass/review.scss', dist + '/css')
    .sass(source + '/resources/assets/sass/currencies.scss', dist + '/css');

mix
    .js(source + '/resources/assets/js/account-admin.js', dist + '/js')
    .sass(source + '/resources/assets/sass/account-admin.scss', dist + '/css')
    .sass(source + '/resources/assets/sass/account.scss', dist + '/css');

mix
    .js(source + '/resources/assets/js/app.js', dist + '/js')
    .sass(source + '/resources/assets/sass/app.scss', dist + '/css')
    .js(source + '/resources/assets/js/bulk-import.js', dist + '/js')
    .js(source + '/resources/assets/js/export.js', dist + '/js')
    .js(source + '/resources/assets/js/duplicate-property.js', dist + '/js')
    .js(source + '/resources/assets/js/project-import.js', dist + '/js')
    .js(source + '/resources/assets/js/setting.js', dist + '/js')

    .copyDirectory(dist + '/js', source + '/public/js')
    .copyDirectory(dist + '/css', source + '/public/css');
