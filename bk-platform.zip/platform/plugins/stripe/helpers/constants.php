<?php

if (! defined('STRIPE_PAYMENT_METHOD_NAME')) {
    define('STRIPE_PAYMENT_METHOD_NAME', 'stripe');
}
