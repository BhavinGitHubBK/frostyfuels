<?php

namespace Botble\Location\Repositories\Eloquent;

use Botble\Location\Repositories\Interfaces\CountryInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class CountryRepository extends RepositoriesAbstract implements CountryInterface
{
}
