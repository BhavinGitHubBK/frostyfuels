<?php

namespace Botble\Location\Repositories\Caches;

use Botble\Location\Repositories\Eloquent\StateRepository;

/**
 * @deprecated
 */
class StateCacheDecorator extends StateRepository
{
}
