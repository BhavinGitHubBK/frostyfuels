<?php

return [
    'name' => 'States',
    'create' => 'New state',
    'country' => 'Country',
    'select_country' => 'Select a country...',
    'state' => 'State',
];
