<?php

return [
    'name' => 'Cities',
    'create' => 'New city',
    'state' => 'State',
    'select_state' => 'Select state...',
    'select_city' => 'Select city...',
    'country' => 'Country',
    'select_country' => 'Select country...',
    'city' => 'City',
];
