<?php

if (! defined('PAYPAL_PAYMENT_METHOD_NAME')) {
    define('PAYPAL_PAYMENT_METHOD_NAME', 'paypal');
}
