<strong>{{ trans('plugins/payment::payment.payment_details') }}: </strong>
@include('plugins/paypal::detail', compact('payment'))
